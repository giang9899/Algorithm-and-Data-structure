package myPackage;
//Tạo linked list.
public class MyList {
    Node head;
    Node tail;

    public MyList() {
        head = null;
        tail = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void clear() {
        head = tail = null;
    }
    
    public int length() {
        if (isEmpty()) {
            return 0;
        }
        int length = 0;
        Node currentNode = this.head;
        while (currentNode != null) {
            length += 1;
            currentNode = currentNode.nextNode;
        }
        return length;
    }
    public void addLast(Product product) {
        Node newNode = new Node(product);
        if (head == null) {
            head = newNode;
            tail = newNode;
        }else {
            tail.nextNode = newNode;
            tail = newNode;
        }
    }
    public void display() {
        System.out.println("\nID | Title | Quantity | Price" + 
                    "\n_________________________________");
        Node current = head;
        while(current != null) {
            System.out.println(current.data);
            current = current.nextNode;
        } 
    }
}
