package myPackage;

public class Myqueue {
    Node head;
    Node tail;

    public Myqueue() {
        head = tail = null;
    }
    //thêm 1 đối tượng vào Queue.
    public void enqueue(Product product) {
       Node newNode = new Node(product);
       newNode.nextNode = null;
       if (head == null) {
           head = newNode;
           tail = newNode;
       }else {
        tail.nextNode = newNode;
        tail = newNode;
       }
    }
    //in ra console.
    public void dequeue() {
        System.out.println("\nID | Title | Quantity | Price" + 
        "\n_________________________________");
        Node current = head;
        while (current != null) {
            System.out.println(current.data);
            current = current.nextNode;
        }
    }
}
