package myPackage;
//Tạo Stack.
public class Mystack {
    Node head;

    public Mystack() {
        head = null;
    }
    public void push(Product product) {
        Node newNode = new Node(product);
        newNode.nextNode = head;
        head = newNode;
    }
    public void pop() {
        System.out.println("\nID | Title | Quantity | Price" + 
                    "\n_________________________________");
        while(head!=null) {
            Product product = head.data;
            head = head.nextNode;
            System.out.println(product.toString());
        }
    }
}
