package myPackage;

import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class OperationToProduct {
    //tạo đối tượng với các thuộc tính được nhập vào từ bàn phím.
    public Product createProduct() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input new ID: ");
        String id = scanner.next();
        System.out.print("Input Product's Name: ");
        String name = scanner.next();
        System.out.print("Input Product's Quantity: ");
        int quantity = scanner.nextInt();
        System.out.print("Input Product's Price: ");
        double price = scanner.nextDouble();
        Product product = new Product(id, name, quantity, price);
        return product;
    }
    //thêm 1 nút có dữ liệu là product vào linked list.
    public void addLast(MyList list) {
        list.addLast(createProduct());
    }
    //Tìm kiếm theo id.
    public void searchByCode(MyList list) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input the ID to search = ");
        String id = scanner.next();
        System.out.println("\nID | Title | Quantity | Price" + "\n_________________________________");
        Node current = list.head;
        boolean answer = true;
        while (current != null) {
            if (current.data.getId().equals(id)) {
                answer = false;
                System.out.println(current.data);
            }
            current = current.nextNode;
        }
        if (answer) {
            System.out.println(-1);
        }
    }
    //hiển thị thông tin sản phẩm trong linked list ra console
    public void displayAll(MyList list) {
        list.display();
    }
    //xóa 1 sản phẩm theo id nhập vào.
    public void deleteByCode(MyList list) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input the ID to delete = ");
        String id = scanner.next();
        Node temp = list.head;
        boolean find = false;
        if (list.isEmpty()) {
            return;
        } else {
            Node prev = null;
            while (temp != null) {
                if (temp.data.getId().equals(id)) {
                    find = true;
                    break;
                }
                prev = temp;
                temp = temp.nextNode;
            }
            if (find) {
                if (temp == list.head) {
                    list.head = list.head.nextNode;
                    temp.nextNode = null;
                } else if (temp.nextNode == null) {
                    list.tail = prev;
                    prev.nextNode = null;
                } else {
                    prev.nextNode = temp.nextNode;
                    temp.nextNode = null;
                }
                System.out.println("Deleted!\n");
            } else {
                System.out.println("ID sản phẩm không đúng.");
            }
        }
    }
    //sắp xếp theo id thứ tự tăng dần.
    public void sortList(MyList list) {
        Node current = list.head;
        Node index = null;
        Product p;
        if (list.isEmpty()) {
            return;
        } else {
            while (current != null) {
                index = current.nextNode;
                while (index != null) {
                    if ((current.data.getId()).compareTo((index.data.getId())) > 0) {
                        p = current.data;
                        current.data = index.data;
                        index.data = p;
                    }
                    index = index.nextNode;
                }
                current = current.nextNode;
            }
        }
    }
    //chia số lấy dư và lưu các số đó vào mảng.
    public int[] convertBinary(int no) {
        int i = 0, temp[] = new int[7];
        int binary[];
        while (no > 0) {
            temp[i++] = no % 2;
            no /= 2;
        }
        binary = new int[i];
        int k = 0;
        //lưu vào mảng theo chiều ngược lại.
        for (int j = i - 1; j >= 0; j--) {
            binary[k++] = temp[j];
        }
     
        return binary;
    }
    //Lấy các số được lưu ra khỏi mảng.
    public void convertToBinary(MyList list) {
        int[] array = convertBinary(list.head.data.getQuantity());
        String binary = "";
        for (int i = 0; i < array.length; i++) {
            binary += array[i] + "";
        }
        System.out.println("Quantity = " + list.head.data.getQuantity() + " => (" + binary + ")");
    }
    //lưu thông tin từ linked list vào file text.
    public void writeAllItemsToFile(MyList list) {
        Node current = list.head;
        try {
            FileOutputStream file = new FileOutputStream(new File("Data.txt"));
            ObjectOutputStream oos = new ObjectOutputStream(file);
            while(current != null) {
                oos.writeObject(current.data);
                current = current.nextNode;
            }
            System.out.println("Successfully!");
            oos.close();
            file.close();
        } catch (FileNotFoundException e) {
            System.out.println("Không tìm thấy file!");
        } catch (IOException e) {
        } catch (ClassCastException e) {
            e.printStackTrace();
        }
    }
    //đọc tất cả đối tượng trong file text và lưu vào linked list
    public void readFile(MyList list) {
        boolean cont = true;
            try {
                FileInputStream fi = new FileInputStream(new File("Data.txt"));
                ObjectInputStream oi = new ObjectInputStream(fi);
                while (cont) {
                    Product product = (Product) oi.readObject();
                    if (product != null) {
                        list.addLast(product);
                    }else {
                        cont = false;
                    }
                }
                
                oi.close();
                fi.close();
    
            } catch (FileNotFoundException e) {
                System.out.println("Không tìm thấy file!");
            } catch (IOException e) {
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            list.display();
    }
    //đọc tất cả đối tượng trong file text và lưu vào Stack.
    public void readFileStack(Mystack list) {
        boolean cont = true;
            try {
                FileInputStream fi = new FileInputStream(new File("Data.txt"));
                ObjectInputStream oi = new ObjectInputStream(fi);
                while (cont) {
                    Product product = (Product) oi.readObject();
                    if (product != null) {
                        list.push(product);
                    }else {
                        cont = false;
                    }
                }
                oi.close();
                fi.close();
    
            } catch (FileNotFoundException e) {
                System.out.println("Không tìm thấy file!");
            } catch (IOException e) {
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
    }
    //hiển thị stack ra console
    public void displayStack(Mystack list) {
        list.pop();
    }
    //đọc tất cả đối tượng trong file text và lưu vào Queue.
    public void readFileQueue(Myqueue list) {
        boolean cont = true;
            try {
                FileInputStream fi = new FileInputStream(new File("Data.txt"));
                ObjectInputStream oi = new ObjectInputStream(fi);
                while (cont) {
                    Product product = (Product) oi.readObject();
                    if (product != null) {
                        list.enqueue(product);
                    }else {
                        cont = false;
                    }
                }
                oi.close();
                fi.close();
    
            } catch (FileNotFoundException e) {
                System.out.println("Không tìm thấy file!");
            } catch (IOException e) {
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
    }
    //in queue ra console.
    public void displayQ(Myqueue list) {
        list.dequeue();
    }
}
