package myPackage;

public class Node {
    //Tạo 1 node với dữ liệu là 1 đối tượng.
    Product data;
    Node nextNode;

    public Node() {
        
    }

    public Node(Product data) {
        this.data = data;
    }

    public Node(Product data, Node nextNode) {
        this.data = data;
        this.nextNode = nextNode;
    }
}
