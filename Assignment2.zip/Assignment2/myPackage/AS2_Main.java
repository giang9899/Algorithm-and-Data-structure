package myPackage;

import java.util.Scanner;

public class AS2_Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean answer;// điều kiện để kết thúc vòng lặp chọn chức năng
        MyList myList = new MyList();// khởi tạo đối tượng linked list
        Mystack listStack = new Mystack();// stack
        Myqueue listQueue = new Myqueue();// Queue.
        OperationToProduct operation = new OperationToProduct(); //đối tượng chứa các chức năng chính của chương trình.
        do {
            answer = true;
            //các chức năng của chương trình.
            System.out.println("Choose one of this options:\nProduct list:");
            System.out.println(" 1. Load data from file and display.");
            System.out.println(" 2. Input & add to the end.");
            System.out.println(" 3. Display data.");
            System.out.println(" 4. Save product list to file.");
            System.out.println(" 5. Search by ID.");
            System.out.println(" 6. Delete by ID.");
            System.out.println(" 7. Sort by ID.");
            System.out.println(" 8. Convert to Binary.");
            System.out.println(" 9. Load to stack and display.");
            System.out.println("10. Load to queue and display.");
            System.out.println(" 0. Exit.");
            System.out.print("\nChoice: ");
            int choice = sc.nextInt();
            //chọn chức năng.
            switch (choice) {
                case 0:
                    sc.close();
                    System.out.println("\n___Goodbye!___\n");
                    answer = false;
                    break;
                case 1:
                    System.out.println();
                    operation.readFile(myList);
                    System.out.println();
                    break;
                case 2:
                    System.out.println();
                    operation.addLast(myList);
                    System.out.println();
                    break;
                case 3:
                    System.out.println();
                    operation.displayAll(myList);
                    System.out.println();
                    break;
                case 4:
                    System.out.println();
                    operation.writeAllItemsToFile(myList);
                    System.out.println();
                    break;
                case 5:
                    System.out.println();
                    operation.searchByCode(myList);
                    System.out.println();
                    break;
                case 6:
                    System.out.println();
                    operation.deleteByCode(myList);
                    System.out.println();
                    break;
                case 7:
                    System.out.println();
                    operation.sortList(myList);
                    System.out.println("Successfully!\n");
                    break;
                case 8:
                    operation.convertToBinary(myList);
                    System.out.println();
                    break;
                case 9:
                    operation.readFileStack(listStack);
                    operation.displayStack(listStack);
                    System.out.println();
                    break;
                case 10:
                    operation.readFileQueue(listQueue);
                    operation.displayQ(listQueue);
                    System.out.println();
                    break;
                default:
                    System.out.println();
                    System.out.println("CHỌN CHỨC NĂNG CHƯA ĐÚNG! HÃY CHỌN LẠI.");
                    System.out.println();
                    break;
            }
        } while (answer);
    }
}